/***************************************************************************************************************
||||||||||||||||||||||||||||         CUSTOM SCRIPT FOR Nothing ham          ||||||||||||||||||||||||||||||||||||
****************************************************************************************************************
||||||||||||||||||||||||||||              TABLE OF CONTENT                  ||||||||||||||||||||||||||||||||||||
****************************************************************************************************************
****************************************************************************************************************
1. mainmenu
2. revolutionSliderActiver
3. accordion box
4. customer carousel
5. counter number changer
6. testimonaial slide 
7. Brand Carousel
8. Customer Feedback
9. Gallery lightbox
10. Sticky header
11. contact form validation
12. theme animation
13. scroll to target
****************************************************************************************************************
||||||||||||||||||||||||||||            End TABLE OF CONTENT                ||||||||||||||||||||||||||||||||||||
****************************************************************************************************************/

"use strict";



// 1. mainmenu
function mainmenu() {
	//Submenu Dropdown Toggle
	if($('.main-menu li.dropdown ul').length){
		$('.main-menu li.dropdown').append('<div class="dropdown-btn"></div>');
		
		//Dropdown Button
		$('.main-menu li.dropdown .dropdown-btn').on('click', function() {
			$(this).prev('ul').slideToggle(500);
		});
	}
	
}



// 2. revolutionSliderActiver
function revolutionSliderActiver() {
    if ($('.rev_slider_wrapper #slider1').length) {
        jQuery("#slider1").revolution({
            sliderType: "standard",
            sliderLayout: "auto",
            dottedOverlay:"yes",
            delay: 5000,
            navigation: {
                arrows: { enable: true }
            },
            gridwidth: 1170,
            gridheight: 660
        });
    };
    if ($('.rev_slider_wrapper #slider2').length) {
        var height = $("#slider2").data('height');
        var sDelay = $("#slider2").data('delay');
        if (!height) {
            height = 825;
        };
        if (!sDelay) {
            sDelay = 5000;
        };

        $("#slider2").revolution({
            sliderType: "standard",
            sliderLayout: "auto",
            delay: sDelay,
            navigation: {
                arrows: { enable: true }
            },
            gridwidth: 1170,
            gridheight: height
        });
    };
}


// 3. accordion box
if($('.accordion-box').length){
    $(".accordion-box").on('click', '.accord-btn', function() {

        if($(this).hasClass('active')!==true){
        $('.accordion .accord-btn').removeClass('active');

        }

        if ($(this).next('.accord-content').is(':visible')){
            $(this).removeClass('active');
            $(this).next('.accord-content').slideUp(500);
        }else{
            $(this).addClass('active');
            $('.accordion .accord-content').slideUp(500);
            $(this).next('.accord-content').slideDown(500);	
        }
    });	
}



// 4. customer carousel
function customerCarousel () {
    if ($('.customer-review').length) {
        $('.customer-review').owlCarousel({
            dots: false,
            loop:true,
            margin:30,
            nav:true,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>'
            ],
            autoplayHoverPause: true,
            smartSpeed: 1000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                800:{
                    items:1
                },
                1024:{
                    items:1
                },
                1100:{
                    items:1
                },
                1200:{
                    items:1
                }
            }
        });    		
    }
}

// 5. counter number changer
function CounterNumberChanger () {
	var timer = $('.timer');
	if(timer.length) {
		timer.appear(function () {
			timer.countTo();
		})
	}

}



// 6. testimonaial slide 
function testimonialSlide () {
    var sliderContainer = $('.testimonial-slide');
    var customPager = $('.testimonial.custom-pager li[data-slide-index]');
    if (sliderContainer.length) {
        var slider = sliderContainer.bxSlider({
            auto: false,
            autoControls: false,
            controls: false,
            pager: false,
            autoHover: true,
            minSlides: 1,
            onSlideNext: function () {
                var current = slider.getCurrentSlide();		    		
                customPager.each(function () {
                    var Slef = $(this);
                    var slideIndex = $(this).data('slide-index');
                    if (slideIndex === current) {
                        customPager.removeClass('active');
                        Slef.addClass('active');
                    }
                });
            }
        });
        customPager.each(function () {
            var slideIndex = $(this).data('slide-index');
            $(this).on('click', function () {
                customPager.removeClass('active');
                $(this).addClass('active');
                slider.goToSlide(slideIndex);
            });
        });
        $('#testimonials .custom-pager li.prev').on('click', function () {
            var current = slider.getCurrentSlide();
            slider.goToPrevSlide(current) - 1;
        });
        $('#testimonials .custom-pager li.next').on('click', function () {
            var current = slider.getCurrentSlide();
            slider.goToNextSlide(current) + 1;
        });
    };
}



// 7. Brand Carousel
function brandCarousel () {
    if ($('.brand').length) {
        $('.brand').owlCarousel({
            dots: false,
            loop:true,
            autoplay: 5000,
            margin:30,
            nav:true,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>'
            ],
            autoplayHoverPause: true,
            smartSpeed: 500,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                800:{
                    items:3
                },
                1024:{
                    items:4
                },
                1100:{
                    items:5
                },
                1200:{
                    items:6
                }
            }
        });    		
    }
}




// 8. Customer Feedback
function customerFeedback () {
    if ($('.customer-feedback').length) {
        $('.customer-feedback').owlCarousel({
            dots: false,
            loop:true,
            autoplay: 5000,
            margin:40,
            nav:true,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>'
            ],
            autoplayHoverPause: true,
            smartSpeed: 500,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                800:{
                    items:2
                },
                1024:{
                    items:2
                },
                1100:{
                    items:2
                },
                1200:{
                    items:2
                }
            }
        });    		
    }
}

// 9. Gallery lightbox
function GalleryLightActivator() {
    if ($('.img-popup').length) {
        var groups = {};
        $('.img-popup').each(function() {
            var id = parseInt($(this).attr('data-group'), 10);

            if (!groups[id]) {
                groups[id] = [];
            }

            groups[id].push(this);
        });


        $.each(groups, function() {

            $(this).magnificPopup({
                type: 'image',
                closeOnContentClick: true,
                closeBtnInside: false,
                gallery: { enabled: true }
            });

        });

    };
}

// 10. Sticky header
function stickyHeader() {
    if ($('.stricky').length) {
        // var strickyScrollPos = 100;
        var strickyScrollPos = $('.stricky').next().offset().top;
        if ($(window).scrollTop() > strickyScrollPos) {
            $('.stricky').addClass('stricky-fixed');
            $('.scroll-to-top').fadeIn(500);
        } else if ($(this).scrollTop() <= strickyScrollPos) {
            $('.stricky').removeClass('stricky-fixed');
            $('.scroll-to-top').fadeOut(500);
        }
    };
}

// 11. contact form validation
function contactFormValidation() {
    if ($('.contact-form-validate').length) {
        $('.contact-form-validate').each(function () {
            var mainCf = $(this);
            mainCf.validate({ // initialize the plugin
                rules: {
                    name: {
                        required: true
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    message: {
                        required: true
                    },
                    subject: {
                        required: true
                    }
                },
                submitHandler: function(form) {
                    // sending value with ajax request
                    $.post($(form).attr('action'), $(form).serialize(), function(response) {
                        $(form).find('.form-result').append(response);
                        $(form).find('input[type="text"]').val('');
                        $(form).find('input[type="email"]').val('');
                        $(form).find('textarea').val('');
                        console.log(response);
                    });
                    return false;
                }
            });            
        });
        
    }
}
// 12. theme animation
function thmScrollAnim() {
    if ($('.wow').length) {
        var wow = new WOW({
            mobile: false
        });
        wow.init();
    };
}
// 13. scroll to target
function scrollToTarget() {
    if ($('.scroll-to-target').length) {
        $(".scroll-to-target").on('click', function() {
            var target = $(this).attr('data-target');
            // animate
            $('html, body').animate({
                scrollTop: $(target).offset().top
            }, 1000);

        });
    }
}


// Dom Ready Function
jQuery(document).on('ready', function () {
    (function ($) {
        // add your functions
        mainmenu();
        revolutionSliderActiver();
        customerCarousel();
        CounterNumberChanger();
        testimonialSlide();
        brandCarousel();
        customerFeedback();
        GalleryLightActivator();
        contactFormValidation();
        thmScrollAnim();
        scrollToTarget();

    })(jQuery);
});

// Dom Ready Function
jQuery(window).on('scroll', function () {
	(function ($) {
		// add your functions
        stickyHeader();

	})(jQuery);
});



