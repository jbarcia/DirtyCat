(function ($) {
	"use strict";

	/*----------  Smooth Scroll  ----------*/
	// var $window = $(window);
	// var scrollTime = .45;
	// var scrollDistance = 350;
	// $window.on("mousewheel DOMMouseScroll", function(event){
	// 	event.preventDefault();
	// 	var delta = event.originalEvent.wheelDelta/120 || -event.originalEvent.detail/3;
	// 	var scrollTop = $window.scrollTop();
	// 	var finalScroll = scrollTop - parseInt(delta*scrollDistance, 10);
	// 	TweenMax.to($window, scrollTime, {
	// 		scrollTo : { y: finalScroll, autoKill:true },
	// 			ease: Power1.easeOut,
	// 			overwrite: 5
	// 		});
	// });

	/*==========  Responsive Navigation  ==========*/
	$('.main-nav').children().clone().appendTo('.responsive-nav');
	$('.responsive-menu-open').on('click', function(event) {
		event.preventDefault();
		$('body').addClass('no-scroll');
		$('.responsive-menu').addClass('open');
		return false;
	});
	$('.responsive-menu-close').on('click', function(event) {
		event.preventDefault();
		$('body').removeClass('no-scroll');
		$('.responsive-menu').removeClass('open');
		return false;
	});
	if ($(window).width() <= 1200) {
		$('#top-collapse').collapse('hide');
	} else {
		$('#top-collapse').collapse('show');
	}
	$(window).resize(function() {
		if ($(window).width() <= 1200) {
			$('#top-collapse').collapse('hide');
		} else {
			$('#top-collapse').collapse('show');
		}
	});
	$('#top-collapse').on('show.bs.collapse', function() {
		$('.top-collapse-open').addClass('open');
		setTimeout(function() { $('.header .top .dropdown-menu').css('display', 'block'); }, 501);
		setTimeout(function() { $('.search-bar.open').css('top',$('.header .top').outerHeight()); }, 501);
	});
	$('#top-collapse').on('hide.bs.collapse', function() {
		$('.top-collapse-open').removeClass('open');
		$('.header .top .dropdown-menu').css('display', 'none');
		setTimeout(function() { $('.search-bar.open').css('top',$('.header .top').outerHeight()); }, 501);
	});
	$('#top-collapse').css('height','');
	$('.responsive-nav li').each(function(index) {
		if ($(this).find('ul').length) {
			var text = $(this).find('> a').text();
			var id = text.replace(/\s+/g, '-').toLowerCase();
			$(this).find('> a').attr('href', '#collapse-' + id);
			$(this).find('> a').attr('data-toggle', 'collapse');
			$(this).find('> a').append('<i class="lnr lnr-chevron-down"></i>');
			$(this).find('> ul').attr('id', 'collapse-' + id);
			$(this).find('> ul').addClass('collapse');
		}
	});
	$('.responsive-nav a').on('click', function() {
		if ($(this).parent().hasClass('collapse-active')) {
			$(this).parent().removeClass('collapse-active');
		} else {
			$(this).parent().addClass('collapse-active');
		}
	});

	/*----------  Search Bar  ----------*/
	$('.search-open').on('click', function(event) {
		event.preventDefault();
		$('.search-bar').addClass('open');
		$('.search-bar.open').css('top',$('.header .top').outerHeight());
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf("MSIE ");
		if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
			
		} else {
			setTimeout(function() { $('#search-text').focus(); }, 50);
		}
		return false;
	});
	$('.search-close').on('click', function(event) {
		event.preventDefault();
		$('.search-bar').removeClass('open');
		return false;
	});

	/*----------  Shopping Cart  ----------*/
	$('.cart-open').on('click', function(event) {
		event.preventDefault();
		$('.shopping-cart').toggleClass('open');
		return false;
	});

	/*----------  Scroll Top  ----------*/
	var scroll_top_duration = 700,
		$back_to_top = $('.go-top');
	$back_to_top.on('click', function(event){
		event.preventDefault();
		$('body,html').animate({
			scrollTop: 0 ,
		 	}, scroll_top_duration
		);
	});

	/*----------  Recent News Slider  ----------*/
	$('.recent-news-slider').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>']
	});

	/*----------  Full Screen Slider  ----------*/
	$('.home-slider').on('initialized.owl.carousel changed.owl.carousel', function(event) {
		$('.video-bg').removeClass('loaded');
		$('.video-bg>div').remove();
		var item = event.item.index;
		var src = $(event.target).find('.owl-item').eq(item).find('.video-bg');
		$(src).YTPlayer({
			fitToBackground: false,
			videoId: '775JskvPCmw',
			ratio: 16/9
		});
	});
	$('.home-slider').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		smartSpeed: 700,
		mouseDrag: false,
		touchDrag: false,
		autoHeight: true
	});
	$('.home-slider').on('resized.owl.carousel', function(event) {
		var $this = $(this);
		$this.find('.owl-height').css('height', $this.find('.owl-item.active').height());
	});

	/*----------  Video Popup  ----------*/
	$('.video-popup').nivoLightbox({
		afterShowLightbox: function() {
			var src = $('.nivo-lightbox-content > iframe').attr('src');
			$('.nivo-lightbox-content > iframe').attr('src', src + '?autoplay=1');
			if ($(window).width() < 769) {
				var height = $('.nivo-lightbox-content iframe').height() / 2 + 28;
				$('.nivo-lightbox-close').css('margin-top', -height);
			}
		},
		beforeShowLightbox: function() {
			$('.video-popup').find('i').removeClass('pe-7s-play');
			$('.video-popup').find('i').addClass('pe-7s-pause');
		},
		afterHideLightbox: function() {
			$('.video-popup').find('i').removeClass('pe-7s-pause');
			$('.video-popup').find('i').addClass('pe-7s-play');
		}
	});

	/*----------  Map Tab  ----------*/
	$('.contact-tab-select').on('change', function(e) {
		$('.map-tab li a').eq($(this).val()).tab('show');
		$('.contacts-tab li a').eq($(this).val()).tab('show');
	});
	$(".map-tab a").on('shown.bs.tab', function() {
		var map_center = map.getCenter();
		var uk_map_center = uk_map.getCenter();
		google.maps.event.trigger(map, 'resize');
		google.maps.event.trigger(uk_map, 'resize');
		map.setCenter(map_center);
		uk_map.setCenter(uk_map_center);
	});

	/*----------  Industries Slider  ----------*/
	$('.industries-slider').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>']
	});
	$('.large-industries-slider').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		animateOut: 'fadeOut',
		animateIn: 'slideInRight',
		autoHeight: true
	});
	$('.large-industries-slider').on('resized.owl.carousel', function(event) {
		var $this = $(this);
		$this.find('.owl-height').css('height', $this.find('.owl-item.active').height());
	});

	/*----------  Clients Slider  ----------*/
	$('.clients-slider').owlCarousel({
		items: 2,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		responsive: {
			0: {
				items: 1
			},
			768: {
				items: 2
			}
		}
	});

	/*----------  Publications Slider  ----------*/
	$('.publications-slider').owlCarousel({
		items: 2,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		margin: 28,
		responsive: {
			0: {
				items: 1
			},
			768: {
				items: 2
			}
		}
	});

	/*----------  Service Icon Slider  ----------*/
	$('.service-icon-slider').owlCarousel({
		items: 2,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		responsive: {
			0: {
				items: 1
			},
			768: {
				items: 2
			}
		}
	});

	/*----------  Testimonial Slider  ----------*/
	$('.testimonial-slider').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>']
	});

	/*----------  News Slider  ----------*/
	$('.news-slider').owlCarousel({
		items: 3,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		margin: 30,
		responsive: {
			0: {
				items: 1
			},
			768: {
				items: 3
			}
		}
	});

	/*----------  Services Slider  ----------*/
	$('.services-slider').owlCarousel({
		items: 3,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>'],
		margin: 20,
		center: true,
		responsive: {
			0: {
				items: 1
			},
			768: {
				items: 3
			}
		}
	});

	/*----------  Image Slider  ----------*/
	$('.image-slider').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText: ['<i class="pe-7s-angle-left"></i>','<i class="pe-7s-angle-right"></i>']
	});

	/*----------  Counters  ----------*/
	$('.countTo').each(function(index) {
		var countTo = $(this);
		countTo.waypoint(function() {
			countTo.countTo({
				speed: 1200
			});
		}, {
			offset: 'bottom-in-view'
		});
	});

	/*==========  Accordion  ==========*/
	$('.panel-heading a').on('click', function() {
		if ($(this).parents('.panel-heading').hasClass('active')) {
			$('.panel-heading').removeClass('active');
		} else {
			$('.panel-heading').removeClass('active');
			$(this).parents('.panel-heading').addClass('active');
		}
	});

	$('.portfolio').imagesLoaded(function() {
		if ($(window).width() > 770) {
			$('.portfolio .item').each(function(index) {
				var $this = $(this);
				var height = $this.height();
				$this.find('.overlay').width(height);
			});
		}
		return false;
	});
	/*----------  Portfolio 3 Col  ----------*/
	var $projects3ColContainer = $('#portfolio3Col').imagesLoaded(function() {
		$projects3ColContainer.isotope({
			itemSelector: '.item',
			layoutMode: 'fitRows',
			percentPosition: true,
			masonry: {
				columnWidth: $projects3ColContainer.find('.portfolio-sizer')[0]
			}
		});
		return false;
	});
	$('#portfolio3Col-filters').on('click', 'button', function() {
		$('#portfolio3Col-filters button').removeClass('active');
		$(this).addClass('active');
		var filterValue = $(this).attr('data-filter');
		$projects3ColContainer.isotope({filter: filterValue});
	});
	/*----------  Portfolio 2 Col  ----------*/
	var $projects2ColContainer = $('#portfolio2Col').imagesLoaded(function() {
		$projects2ColContainer.isotope({
			itemSelector: '.item',
			layoutMode: 'fitRows',
			percentPosition: true,
			masonry: {
				columnWidth: $projects2ColContainer.find('.portfolio-sizer')[0]
			}
		});
		return false;
	});
	$('#portfolio2Col-filters').on('click', 'button', function() {
		$('#portfolio2Col-filters button').removeClass('active');
		$(this).addClass('active');
		var filterValue = $(this).attr('data-filter');
		$projects2ColContainer.isotope({filter: filterValue});
	});
	/*----------  Portfolio Masonry  ----------*/
	var $projectsMasonryContainer = $('#portfolioMasonry').imagesLoaded(function() {
		$projectsMasonryContainer.isotope({
			itemSelector: '.item',
			layoutMode: 'fitRows',
			percentPosition: true,
			masonry: {
				columnWidth: $projectsMasonryContainer.find('.portfolio-sizer')[0]
			}
		});
		return false;
	});
	$('#portfolioMasonry-filters').on('click', 'button', function() {
		$('#portfolioMasonry-filters button').removeClass('active');
		$(this).addClass('active');
		var filterValue = $(this).attr('data-filter');
		$projectsMasonryContainer.isotope({filter: filterValue});
	});
	
	/*==========  Validate Email  ==========*/
	function validateEmail($validate_email) {
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if( !emailReg.test( $validate_email ) ) {
			return false;
		} else {
			return true;
		}
		return false;
	}
	
	/*==========  Contact Form  ==========*/
	$('#contact-form').on('submit', function() {
		$('#contact-error').fadeOut();
		$('#contact-success').fadeOut();
		$('#contact-loading').fadeOut();
		$('#contact-loading').fadeIn();
		if (validateEmail($('#contact-email').val()) && $('#contact-email').val().length !== 0 && $('#contact-name').val().length !== 0 && $('#contact-message').val().length !== 0) {
			var action = $(this).attr('action');
			$.ajax({
				type: "POST",
				url : action,
				data: {
					contact_name: $('#contact-name').val(),
					contact_email: $('#contact-email').val(),
					contact_phone: $('#contact-phone').val(),
					contact_message: $('#contact-message').val()
				},
				success: function() {
					$('#contact-error').fadeOut();
					$('#contact-success').fadeOut();
					$('#contact-loading').fadeOut();
					$('#contact-success .message').html('Success! Thanks for contacting us!');
					$('#contact-success').fadeIn();
				},
				error: function() {
					$('#contact-error').fadeOut();
					$('#contact-success').fadeOut();
					$('#contact-loading').fadeOut();
					$('#contact-error .message').html('Sorry, an error occurred.');
					$('#contact-error').fadeIn();
				}
			});
		} else if (!validateEmail($('#contact-email').val()) && $('#contact-email').val().length !== 0 && $('#contact-name').val().length !== 0 && $('#contact-message').val().length !== 0) {
			$('#contact-error').fadeOut();
			$('#contact-success').fadeOut();
			$('#contact-loading').fadeOut();
			$('#contact-error .message').html('Please enter a valid email.');
			$('#contact-error').fadeIn();
		} else {
			$('#contact-error').fadeOut();
			$('#contact-success').fadeOut();
			$('#contact-loading').fadeOut();
			$('#contact-error .message').html('Please fill out all the fields.');
			$('#contact-error').fadeIn();
		}
		return false;
	});

	/*==========  Newsletter Form  ==========*/
	var $form = $('#mc-embedded-subscribe-form');
	$form.submit(function() {
		$('#newsletter-error').fadeOut();
		$('#newsletter-success').fadeOut();
		$('#newsletter-loading').fadeOut();
		$('#newsletter-info').fadeOut();
		$('#newsletter-loading').fadeIn();
		if (validateEmail($('#mce-EMAIL').val()) && $('#mce-EMAIL').val().length !== 0) {
			$.ajax({
				type: $form.attr('method'),
				url: $form.attr('action'),
				data: $form.serialize(),
				cache: false,
				dataType: 'json',
				contentType: 'application/json; charset=utf-8',
				error: function(err) {
					$('#newsletter-error').fadeOut();
					$('#newsletter-success').fadeOut();
					$('#newsletter-loading').fadeOut();
					$('#newsletter-info').fadeOut();
					$('#newsletter-error .message').html(err.msg);
					$('#newsletter-error').fadeIn();
				},
				success: function(data) {
					if (data.result !== 'success') {
						$('#newsletter-error').fadeOut();
						$('#newsletter-success').fadeOut();
						$('#newsletter-loading').fadeOut();
						$('#newsletter-info').fadeOut();
						$('#newsletter-info .message').html(data.msg);
						$('#newsletter-info').fadeIn();
					} else {
						$('#newsletter-error').fadeOut();
						$('#newsletter-success').fadeOut();
						$('#newsletter-loading').fadeOut();
						$('#newsletter-info').fadeOut();
						$('#newsletter-success .message').html(data.msg);
						$('#newsletter-success').fadeIn();
					}
				}
			});
		} else {
			$('#newsletter-error').fadeOut();
			$('#newsletter-success').fadeOut();
			$('#newsletter-loading').fadeOut();
			$('#newsletter-info').fadeOut();
			$('#newsletter-error .message').html('Please enter a valid email.');
			$('#newsletter-error').fadeIn();
		}
		return false;
	});

	/*==========  Map  ==========*/
	var map;
	function initialize_map() {
		if ($('.map').length) {
			var myLatLng = new google.maps.LatLng(-37.814199, 144.961560);
			var mapOptions = {
				zoom: 18,
				center: myLatLng,
				scrollwheel: false,
				panControl: false,
				zoomControl: true,
				scaleControl: true,
				mapTypeControl: false,
				streetViewControl: false,
				draggable: false
			};
			map = new google.maps.Map(document.getElementById('map'), mapOptions);
			var marker = new google.maps.Marker({
				position: myLatLng,
				map: map,
				title: 'Envato',
				icon: './images/marker.png'
			});
		} else {
			return false;
		}
		return false;
	}
	google.maps.event.addDomListener(window, 'load', initialize_map);

	var uk_map;
	function initialize_uk_map() {
		if ($('#uk_map').length) {
			var myLatLng = new google.maps.LatLng(51.493117, -0.146469);
			var mapOptions = {
				zoom: 18,
				center: myLatLng,
				scrollwheel: false,
				panControl: false,
				zoomControl: true,
				scaleControl: true,
				mapTypeControl: false,
				streetViewControl: false,
				draggable: false
			};
			uk_map = new google.maps.Map(document.getElementById('uk_map'), mapOptions);
			var marker = new google.maps.Marker({
				position: myLatLng,
				map: uk_map,
				title: 'Buckingham Palace',
				icon: './images/marker.png'
			});
		} else {
			return false;
		}
		return false;
	}
	google.maps.event.addDomListener(window, 'load', initialize_uk_map);

})(jQuery);