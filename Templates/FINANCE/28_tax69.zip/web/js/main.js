( function($){  
  "use strict";
  
    var wWidth;    
    var slice_testimonial, slice_myblog_post, slice_news_post;
      
    $(window).on('load resize',function(){
        mobile();
        pTmobile();
        myblog_post();
        news_post();
        testimonial_post();      
    }); 

  
    /***************************************
    jquery Myblog Post Mobile View activation code
    ***************************************/

    function myblog_post(){
          wWidth = $(window).width();     
          if(wWidth > 991){
                slice_myblog_post = 6;
          }else{
              slice_myblog_post = 2;
          }
          
        $("div.myblog-post").hide();

        $("div.myblog-post").slice(0, slice_myblog_post).show();        
        $("#loadMore").on('click', function (e) {
            e.preventDefault();
            $("div.myblog-post:hidden").slice(0, slice_myblog_post).slideDown();    
            if ($("div.myblog-post:hidden").length == 0) {
                $(".load-more.myblog-post").fadeOut('slow');
                $(".load-more.allpost").fadeIn('slow');
            }
            $('html,body').animate({
                scrollTop: $(this).offset().bottom
            }, 3000);

        });
    
    }
    
    /***************************************
    jquery Testimonial Post Mobile View activation code
    ***************************************/
    function testimonial_post(){
      wWidth = $(window).width();     
          if(wWidth > 990){
                slice_testimonial = 6;
          }else{
              slice_testimonial = 4;
          }          
          $("div.testimonial-post").hide();
          $("div.testimonial-post").slice(0, slice_testimonial).show();        
          $("#testimonial-more").on('click', function (e) {
              e.preventDefault();
              $("div.testimonial-post:hidden").slice(0, slice_testimonial).slideDown();      
              if ($("div.testimonial-post:hidden").length == 0) {
                  $("#testimonial-more").fadeOut('slow');
                  $(".testimonial-view").fadeIn('slow');
              }
              $('html,body').animate({
                  scrollTop: $(this).offset().bottom
              }, 3000);
          });
      
      }
  
     
    /***************************************
    jquery News Post Mobile View activation code
    ***************************************/

     function news_post(){
          wWidth = $(window).width();     
          if(wWidth > 990){
                slice_news_post = 4;
          }else{
              slice_news_post = 2;
          }          
        $("div.news-post").hide();
        $("div.news-post").slice(0, slice_news_post).show();        
        $("#news-post").on('click', function (e) {
            e.preventDefault();
            $("div.news-post:hidden").slice(0, slice_news_post).slideDown();    
            if ($("div.news-post:hidden").length == 0) {
                $("#news-post").fadeOut('slow');               
                 $(".btn-all-news").fadeIn('slow');          
            }else{
               $("#news-post").fadeIn('slow');               
            }


            $('html,body').animate({
                scrollTop: $("#news-post").offset().bottom
            }, 3000);


        });
    
    }
  

    /***************************************
      * jquery Price Table Carousel Mobile View activation code    
      * jquery services Carousel Mobile View activation code
    ***************************************/
    function pTmobile() {
        var checkWidth = $(window).width()   
        
        var pricetable = $(".price-table-mobile");
        var services = $(".services-mobile");
           
        if (checkWidth > 992) {
           if(pricetable.hasClass('owl-carousel')){
              pricetable.data('owlCarousel').destroy(); 
              pricetable.removeClass('owl-carousel');
            } 
          if(services.hasClass('owl-carousel')){
            services.data('owlCarousel').destroy(); 
            services.removeClass('owl-carousel');
          }    
        } else {          
                pricetable.owlCarousel({       
                items : 1,
                itemsDesktop : false,
                itemsDesktopSmall : [980,1],
                itemsTablet: false,
                itemsTabletSmall: false,
                itemsMobile : false,
                singleItem : false,
                itemsScaleUp : false,
                // Navigation
                navigation : false,
                navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                /* transitionStyle : "fade", */    /* [This code for animation ] */
                // Responsive
                responsive: true,
                pagination:true,

            });
             services.owlCarousel({
                  items : 2,
                  itemsDesktop : false,
                  itemsDesktopSmall : false,
                  itemsTablet: false,
                  itemsTabletSmall: false,
                  itemsMobile : [479,1],
                  singleItem : false,
                  itemsScaleUp : false,
                  // Navigation
                  navigation : false,
                  navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                  /* transitionStyle : "fade", */    /* [This code for animation ] */
                  // Responsive
                  responsive: true,
                  pagination:true, 

            });            

        }
      }

    /***************************************
    * jquery Ourprocess Carousel Mobile View activation code    
    * jquery My Team Carousel Mobile View activation code
    * jquery Our Partners Carousel Mobile View activation code
    * jquery Services Two Carousel Mobile View activation code
    * jquery Blog Carousel Mobile View activation code
    ***************************************/

          function mobile() {
                var checkWidth = $(window).width()   
                var ourprocess = $(".ourprocess-mobile");
                var myteam = $(".myteam-mobile");
                var services = $(".services-mobile"); 
                var ourpartners= $(".ourpartners-mobile");
                var services_2 = $(".services-mobile-2");
                var myblog = $(".myblog-mobile");

                if (checkWidth > 991) {
                        if(ourprocess.hasClass('owl-carousel')){
                          ourprocess.data('owlCarousel').destroy(); 
                          ourprocess.removeClass('owl-carousel');
                        }
                    if(myteam.hasClass('owl-carousel')){
                        myteam.data('owlCarousel').destroy();
                        myteam.removeClass('owl-carousel');
                      }
                       
                    if(services.hasClass('owl-carousel')){
                        services.data('owlCarousel').destroy(); 
                        services.removeClass('owl-carousel');
                      }   
                      if(services_2.hasClass('owl-carousel')){
                        services_2.data('owlCarousel').destroy(); 
                        services_2.removeClass('owl-carousel');
                    }
                    if(myblog.hasClass('owl-carousel')){
                        myblog.data('owlCarousel').destroy(); 
                        myblog.removeClass('owl-carousel');
                    }

                } else {
                    ourprocess.owlCarousel({
                          items : 2,
                          itemsDesktop : false,
                          itemsDesktopSmall : false,
                          itemsTablet: false,
                          itemsTabletSmall: false,
                          itemsMobile : [479,1],
                          singleItem : false,
                          itemsScaleUp : false,
                          // Navigation
                          navigation : false,
                          navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                           /* transitionStyle : "fade", */    /* [This code for animation ] */
                          // Responsive
                          responsive: true,
                          pagination:true, 
                    
                    });
                     myteam.owlCarousel({
                        items : 2,
                          itemsDesktop : false,
                          itemsDesktopSmall : false,
                          itemsTablet: false,
                          itemsTabletSmall: false,
                          itemsMobile : [479,1],
                          singleItem : false,
                          itemsScaleUp : false,
                          // Navigation
                          navigation : false,
                          navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                           /* transitionStyle : "fade", */    /* [This code for animation ] */
                          // Responsive
                          responsive: true,
                          pagination:true,  
                    });
                    services.owlCarousel({                     
                          items : 2,
                          itemsDesktop : false,
                          itemsDesktopSmall : false,
                          itemsTablet: false,
                          itemsTabletSmall: false,
                          itemsMobile : [479,1],
                          singleItem : false,
                          itemsScaleUp : false,
                          // Navigation
                          navigation : false,
                          navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                           /* transitionStyle : "fade", */    /* [This code for animation ] */
                          // Responsive
                          responsive: true,
                          pagination:true, 
                      });
                      ourpartners.owlCarousel({
                          items : 4,
                          itemsDesktop : false,
                          itemsDesktopSmall : false,
                          itemsTablet: false,
                          itemsTabletSmall: false,
                          itemsMobile : [479,2],
                          singleItem : false,
                          itemsScaleUp : false,
                          // Navigation
                          navigation : false,
                          navigationText : ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                           /* transitionStyle : "fade", */    /* [This code for animation ] */
                          // Responsive
                          responsive: true,
                          pagination:true, 
                      });
                      services_2.owlCarousel({
                        items : 3, 
                        slideSpeed : 500,
                        autoPlay : true,
                        stopOnHover : true,
                        navigation : false,
                        pagination : true,
                        responsive: true,
                        itemsDesktop : [991,3],     
                        itemsTablet: [768,2],        
                        itemsMobile : [479,1],
                        navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]  
                         /* transitionStyle : "fade", */    /* [This code for animation ] */
                      });
                       myblog.owlCarousel({
                        items : 2, 
                        slideSpeed : 500,
                        autoPlay : true,
                        stopOnHover : true,
                        navigation : true,
                        pagination : false,
                        responsive: true,
                        itemsDesktop : [991,2],     
                        itemsTablet: [768,2],        
                        itemsMobile : [479,1],
                        navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]  
                      });
          }
      }
  

      /***************************************
      * jquery preloader activation code
      ***************************************/
        $(window).on('load',function(){
          $( "#preloader" ).fadeOut( 'slow', function () {        
            $( this ).remove();

          } );
        });                

      /***************************************
      *  jQuery MeanMenu activation code
      ***************************************/
      $("nav#dropdown").meanmenu();  
  

      /***************************************
      *   wow js active activation code
      ***************************************/   
      new WOW().init();

      /***************************************
      *  Box lauout Change activation code
      ***************************************/  
   
      $("#boxlayout").on('click', function(){        
         $("body").addClass("box");
      });  

      $("#fulllayout").on('click', function(){
       $("body").removeClass("box");
      }); 

      /***************************************
      *   jQuery venobox activation code
      ***************************************/ 
      $(".inline-venobox.inmm").on('click', function(){
            var $imgSRC = $(this).parent('.overlayer').next('.team-img-class').find('img').attr('src');         
            $(".img-2box").find('img').attr('src', $imgSRC);
        });

      $('.venobox').venobox({
        numeratio: true,
        infinigall: true
      });

      $(".inline-team-Detail").on('click', function(){
        var $imgSRC = $(this).next('a').find('img').attr('src');      
        $(".single-staff-right-img").find('img').attr('src', $imgSRC);
      });


   /* $('.btn-read-more').venobox({
      framewidth: '', 
      frameheight: '',  
      border: '10px',    
      titleattr: 'data-title',  
      numeratio: true,           
      infinigall: true  
    });
*/
    /***************************************
    *    accordion activation code
    ***************************************/   
    $('#accordion').children('.panel').children('.panel-collapse').each(function(){
        if($(this).hasClass('in')){
        $(this).parent('.panel').children('.panel-heading').addClass('active');
            var heading = $(this).parent('.panel').children('.panel-heading');
            heading.find('.heading-arrow i.fa').removeClass('fa-angle-down');
            heading.find('.heading-arrow i.fa').addClass('fa-angle-up');
        }
    });

    $('#accordion')
        .on('show.bs.collapse', function(e) {
            $(e.target).prev('.panel-heading').addClass('active');
            var heading = $(e.target).prev('.panel-heading');
            heading.find('.heading-arrow i.fa').removeClass('fa-angle-down');
            heading.find('.heading-arrow i.fa').addClass('fa-angle-up');
        })
        .on('hide.bs.collapse', function(e) {
            $(e.target).prev('.panel-heading').removeClass('active');
            var heading = $(e.target).prev('.panel-heading');
            heading.find('.heading-arrow i.fa').removeClass('fa-angle-up');
            heading.find('.heading-arrow i.fa').addClass('fa-angle-down');
        });

    /***************************************
    *   scrollUp activation code
    ***************************************/   
    $.scrollUp({
          scrollText: '<i class="fa fa-angle-up"></i>',
          easingType: 'linear',
          scrollSpeed: 900,
          animation: 'fade'
      }); 
    
    /***************************************
    *   jquery Stiky Menu activation code
    ***************************************/    

    var navpos = $('#sticker').offset();
    var navheight = $('#sticker').outerHeight();    
    var topheight = $('.header-top-area').outerHeight();
    var mobilemenuarea = $('.mobile-menu-area').outerHeight();
    var windowWidth = $(window).width();     

      $(window).on('scroll', function() {
        if(windowWidth > 767){
    
          if($(".main-header-three").length){ 
              if ($(window).scrollTop() > navpos.top) {
                $("#sticker").addClass('stick');  
            }
            else {
             $("#sticker").removeClass('stick');  
            }
    
          } else {
    
            if ($(window).scrollTop() > navpos.top) {
    
              $("#sticker").addClass('stick');     
              $("body").css('marginTop',navheight);
            }
              else {
                $("#sticker").removeClass('stick');      
                $("body").css('marginTop','0');
              }
            }
          }
    
      if(windowWidth <= 767){
          if($(".main-header-three").length){ 
    
                  if ($(window).scrollTop() > navpos.top) {
                    $(".mobile-menu-area").addClass('stick');  
                }
                else {
                 $(".mobile-menu-area").removeClass('stick');  
                }
            } else {
    
                if ($(window).scrollTop() > navpos.top) {     
                  $(".mobile-menu-area").addClass('stick'); 
                 
                }else {    
                     $(".mobile-menu-area").removeClass('stick');      
                   
                  }
              }
            }
    
          });
      
        /*----------------------------  
        fullheight
        ------------------------------ */
        $('.fullheight').css({"min-height": $(window).height()});

      /*----------------------------  
          
      ------------------------------ */
      $("#ourprocess-carousel").owlCarousel({
        slideSpeed : 300,
        paginationSpeed : 400,
        items : 1, 
        itemsDesktop : false,
        itemsDesktopSmall : false,
        itemsTablet: false,
        itemsMobile : false,
        navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
      });

     /*----------------------------  
          
      ------------------------------ */
      $("#twitter-feed-carousel").owlCarousel({
        slideSpeed : 300,
        paginationSpeed : 400,
        items : 1, 
        itemsDesktop : false,
        itemsDesktopSmall : false,
        itemsTablet: false,
        itemsMobile : false,
        navigationText: ["<i class='fa fa-long-arrow-left' aria-hidden='true'></i>","<i class='fa fa-long-arrow-right' aria-hidden='true'></i>"]              
      });

     /*----------------------------  
     references-carousel-one
      ------------------------------ */
     $(".references-carousel-one").owlCarousel({            
          items : 3, 
          slideSpeed : 500,
          autoPlay : true,
          navigation : true,
          pagination : false,
          responsive: true,
          itemsDesktop : [1199,3],
          itemsDesktopSmall : [991,2],
          itemsTablet: [768,2],        
          itemsMobile : [639,1],
          navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
      });
     
     /*----------------------------  
     references-carousel-one
      ------------------------------ */
     $(".testimonial-carousel-two").owlCarousel({            
          items : 3, 
          slideSpeed : 500,
          autoPlay : true,
          navigation : true,
          pagination : false,
          responsive: true,
          itemsDesktop : [1199,3],
          itemsDesktopSmall : [991,2],
          itemsTablet: [768,2],        
          itemsMobile : [479,1],
          navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
      });
    /*----------------------------  
     references-carousel-one
      ------------------------------ */
    /*team-carousel-one*/

     $(".team-carousel-one").owlCarousel({            
          items : 3, 
          slideSpeed : 500,
          autoPlay : true,
          stopOnHover : true,
          navigation : true,
          pagination : false,
          responsive: true,
          itemsDesktop : [1199,3],
          itemsDesktopSmall : [991,2],
          itemsTablet: [768,2],        
          itemsMobile : [479,1],
          navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
      });
      /*----------------------------  
       references-carousel-one
        ------------------------------ */
       $(".team-carousel-three").owlCarousel({            
            items : 3, 
            slideSpeed : 500,
            autoPlay : true,
            stopOnHover : true,
            navigation : true,
            pagination : false,
            responsive: true,
            itemsDesktop : [1199,3],
            itemsDesktopSmall : [991,2],
            itemsTablet: [768,2],        
            itemsMobile : [479,1],
            navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
        });

       /*----------------------------  
       references-carousel-one
        ------------------------------ */
       $(".blog-carousel").owlCarousel({            
            items : 3, 
            slideSpeed : 500,
            autoPlay : true,
            stopOnHover : true,
            navigation : true,
            pagination : false,
            responsive: true,
            itemsDesktop : [1199,3],
            itemsDesktopSmall : [991,2],
            itemsTablet: [768,2],        
            itemsMobile : [479,1],
            navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
        });

      /*----------------------------  
       references-carousel-one
        ------------------------------ */
      $(".brand").owlCarousel({            
            items :6, 
            slideSpeed : 500,
            autoPlay : true,
            stopOnHover : true,
            navigation : false,
            pagination : true,
            responsive: true,
            itemsDesktop : [1199,4],
            itemsDesktopSmall : [991,3],
            itemsTablet: [768,3],        
            itemsMobile : [479,2],
            navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
          });
          /*----------------------------  
          references-carousel-one
          ------------------------------ */
          $(".ourprocess-carousel-three").owlCarousel({            
              items : 2, 
              slideSpeed : 500,
              autoPlay : true,
              stopOnHover : true,
              navigation : false,
              pagination : true,
              responsive: true,
              itemsDesktop : [1199,2],
              itemsDesktopSmall : [991,2],
              itemsTablet: [768,1],        
              itemsMobile : [479,1],
              navigationText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]        
          });


      /*-------------------------------
      about-counter
      ---------------------------------*/     
      $('.about-counter').counterUp({
        delay: 50,
        time: 3000
      });

 
      /****************************************
       Contact Form code
       ***************************************/
       if($('#contact-form').length){
          $('#contact-form').validator().on('submit', function (e) {
               var $this = $(this),
                    $target = $(".form-response");
               if (e.isDefaultPrevented()) {
                  $target.html("<div class='alert alert-success'><p>Please select all required field.</p></div>");
               } else {
                var name = $("#form-name").val();
                var email = $("#form-email").val();
                var message = $("#form-message").val();
                // ajax call
                 $.ajax({
                   url: 'php/form-process.php',
                   type: 'POST',
                   data: "name=" + name + "&email=" + email + "&message=" + message,
                   beforeSend: function() { 
                      $target.html("<div class='alert alert-info'><p>Loading ...</p></div>");
                  },
                   success: function( text ){
                          if(text == "success"){
                              $this[0].reset();
                              $target.html("<div class='alert alert-success'><p>Message has been sent.</p></div>");
                          } else {
                              $target.html("<div class='alert alert-success'><p>"+text+"</p></div>");
                          }
                       }
                 });

                 return false;
               }
          });
        }

     /****************************************
      *  SmoothScroll activation code
      ***************************************/
      function smoothScroll(target) {
            $("body,html").animate(
              {'scrollTop':target.offset().top},
              600
            );
      }

    /****************************************
    Google Map activation code
    ***************************************/
  if($("#googleMap").length){
    var initialize = function() {
      var mapOptions = {
          zoom: 15,
          scrollwheel: false,
          center: new google.maps.LatLng(-37.81618, 144.95692)
      };

      var map = new google.maps.Map(document.getElementById('googleMap'),
          mapOptions);

      var marker = new google.maps.Marker({
          position: map.getCenter(),
          animation:google.maps.Animation.BOUNCE,
          icon: 'img/map-marker.png',
          map: map
      });

    }
  google.maps.event.addDomListener(window, 'load', initialize);
}


})(jQuery);