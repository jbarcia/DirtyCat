$( document ).ready(function() {"use strict";
             $('.cb').fancySelect();
});
