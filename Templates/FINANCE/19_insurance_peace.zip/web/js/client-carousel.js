// JavaScript Document
$(document).ready(function() {
 "use strict";
  $("#client-demo").owlCarousel({
 	  autoPlay: 3000, //Set AutoPlay to 3 seconds
	  items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
      navigation : false
});
});