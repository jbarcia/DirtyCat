Cufon.replace('.blog h2, .item-page h2, .title-sub, .blog-featured h2, .content-banner h3, .box-banner span, .stylebox1-title, .wrapper-text h3',  { fontFamily: 'Myriad Pro', hover:true });
Cufon.replace('.content-banner h3, .box-banner p',  { fontFamily: 'Myriad Pro con', hover:true });








