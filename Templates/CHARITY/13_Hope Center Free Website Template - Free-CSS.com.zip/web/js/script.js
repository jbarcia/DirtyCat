$(document).ready(function(){
  $("a.new_window").attr("target", "_blank");
 });